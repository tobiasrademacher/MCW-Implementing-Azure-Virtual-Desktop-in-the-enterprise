# Description

Provides a mechanism to run PowerShell script blocks on a target node.
This resource works on Nano Server.
